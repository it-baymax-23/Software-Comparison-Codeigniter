<style>
	.category .fa-times-circle:hover
	{
		color:red;
	}	
</style>
<div class="main-content p-b-50">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
	        <div class="row">
	        	<div class="col-lg-12">
	        		<span class="btn btn-success pull-right saveproduct" style="margin-right:15px;margin-bottom:30px;">Save Product<i class="fas fa-save" style="margin-left:10px;"></i></span>
	        	</div>
		        <div class="col-lg-6" style="padding:0px;">
		        	<div class="card">
			        	<div class="card-header">
			        		<span class="title-3 m-l-30"><i class="fab fa-product-hunt"></i> New Product</span>
			        	</div>
		        		<div class="card-body card-block">
			            	<form action="<?php echo base_url();?>admin/user" method ='post' class="form-horizontal" id="productform" attr_id='<?php if(isset($id)){echo $id;}else{echo '';}?>'>
			            		<div class="form-body">
			            			<h4  class="title-3 m-l-100">MAIN INFO</h4>
			            			<div class="form-group row m-t-30">
			            				<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-3 control-label">Logo</label>
			            				<div class="col col-md-9">
			                                <div class="fileinput fileinput-new" data-provides="fileinput">
			                                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;border:solid 1px grey;">
			                                        <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" /> </div>
			                                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
			                                    <div>
			                                        <span class="btn default btn-file">
			                                            <span class="fileinput-new btn btn-success"> Select image </span>
			                                            <span class="fileinput-exists btn btn-primary"> Change </span>
			                                            <input type="file" name="file" id="logo"> </span>
			                                        <span href="javascript:;" class="btn btn-danger fileinput-exists" data-dismiss="fileinput"> Remove </span>
			                                    </div>
			                                </div>
			                             </div>
			            			</div>
			                		<div class="form-group row" >
			                			<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Name</label>
			                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
			                				<div class="input-group">
			                					<span class="input-group-addon input-circle-left">
			                                        <i class="fa fa-font"></i>
			                                    </span>
			                                    <input type="text" class="form-control maininfo input-circle-right" placeholder="Name" name="name" required> 
			                				</div>
			                			</div>
			                		</div>
			                		<div class="form-group row">
			                			<div class="col col-md-7 categories" style="border-style:solid;border-color:grey;border-width:1px;min-height:70px;margin-right:10px;padding:0px;margin-left:15px;"></div>
			                			<a class="btn btn-primary selectcategory" data-toggle="modal" href="#basic" style="max-height: 40px;">Select Category<i class="fa fa-plus-circle" style="margin-left:12px;"></i></a>
			                		</div>
			                		<div class="form-group row">
			                			<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Description</label>
			                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
			                                <textarea class="form-control maininfo" placeholder="Description" name="description"  rows="7" required> </textarea>
			                			</div>
			                		</div>
			                		<div class="form-group row">
			                			<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Company</label>
			                			<div class="col col-sm-6 col-md-6 col-lg-6 col-xs-12">
			                                <select class="bs-select maininfo form-control" data-live-search="true" data-size="8" name="user_id">
			                                	<?php foreach($vendor as $vendors){?>
			                                	<option value="<?php echo $vendors['id'];?>"><?php echo $vendors['company'];?></option>
			                                	<?php }?>
			                                </select>
			                			</div>
			                		</div>
			                		<div class="form-group row">
			                			<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">About Product</label>
			                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
			                                <textarea class="form-control maininfo" placeholder="Description" name="aboutproduct" rows="7" required> </textarea>
			                			</div>
			                		</div>
			                		<button type="submit" style="display:none" id="productbutton"></button>
			                		</form>
			                		<hr/>
			                		<div class="row m-t-30">
			                			<h4  class="title-3 m-l-100">SCREEN SHOT UPLOAD</h4>
				        				<form action="<?php echo base_url();?>admin/product/upload" class="dropzone dropzone-file-area" id="my-dropzone" style="width: 500px; margin-top: 50px;">
			                                <h3 class="sbold">Drop files here or click to upload The ScreenShot</h3>
			                                <p> You have to upload the screen shot for your software to satisfy the customers </p>
			                            </form>
			                        </div>
			                        <div class="form-group row" style="margin-top: 20px;">
				        				<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Video Url</label>
			                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
			                                <input type="url" class="form-control" name="video">
			                			</div>
				        			</div>
				        			<hr/>
				        			<div class="row" style="margin-top:30px;">
					        			<div class="form-horizontal" id="product_detail">
				        					<div class="form-body col-lg-12">
				        						<h4  class="title-3 m-l-100">Product Details</h4>
					        					<div class="form-group m-t-30 row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Website Url</label>
						                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
						                                <input type="url" class="form-control" placeholder="WebSite Url" name="websiteurl">
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">FreeTrial Url</label>
						                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
						                                <input type="url" class="form-control" placeholder="Free Trial Url" name="freetrial">
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">FreeDemo Url</label>
						                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
						                                <input type="url" class="form-control" placeholder="Free Trial Url" name="freetrial">
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">priceplan Url</label>
						                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
						                                <input type="url" class="form-control" placeholder="Price Plan Url" name="priceplan">
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Who Use It</label>
						                			<div class="col col-sm-6 col-md-9 col-lg-9 col-xs-12">
						                                <input class="form-control" placeholder="Please Seperate The Users with Comma EX:user1,user2" name="who_use">
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Deploy</label>
						                			<div class="col col-sm-5 col-md-8 col-lg-8 col-xs-12" style="margin-left:20px;border-style:solid;border-width:1px;border-color:grey;">
						                				<div class="row" style="margin:10px;" id="deploy">
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="webbase" class="styled" type="checkbox" value="webbase"/>
							                                	<label for="webbase">Web Based</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="windows" class="styled" type="checkbox" value="windows"/>
							                                	<label for="windows">Windows/Installed</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="android" class="styled" type="checkbox" value="android"/>
							                                	<label for="android">Android</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="ios" class="styled" type="checkbox" value="ios"/>
							                                	<label for="ios">IOS</label>	
							                                </div>
							                            </div>
						                			</div>
					        					</div>
					        					<div class="form-group row" class="start_price">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Starting Price / month</label>
						                			<div class="col col-sm-3 col-md-5 col-lg-5 col-xs-8">
						                				<div class="input-group">
							                				<span class="input-group-addon input-circle-left">
						                                        <i class="fa fa-usd"></i>
						                                    </span>
							                                <input class="form-control input-circle-right" placeholder="Please Type your product Starting Price" name="start_price">
							                            </div>
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Price Detail</label>
						                			<div class="col-sm-6 col-md-9 col-lg-9 col-xs-12">
						                                <textarea class="form-control" placeholder="Please Type your product real Price" name="price_detail" rows="7"></textarea>
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Price Model</label>
						                			<div class="col col-sm-5 col-md-8 col-lg-8 col-xs-12" style="margin-left:20px;border-style:solid;border-width:1px;border-color:grey;">
						                				<div class="row" style="margin:10px;" id="pricemodel">
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="free" class="styled" type="checkbox" value="free"/>
							                                	<label for="free">Free</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="freetrial" class="styled" type="checkbox" value="freetrial"/>
							                                	<label for="freetrial">Free Trial</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="onetime" class="styled" type="checkbox" value="onetime"/>
							                                	<label for="onetime">One Time</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="opensource" class="styled" type="checkbox" value="opensource"/>
							                                	<label for="opensource">Open Source</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="subscription" class="styled" type="checkbox" value="subscription"/>
							                                	<label for="subscription">Subscription</label>	
							                                </div>
							                            </div>
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Training</label>
						                			<div class="col col-sm-5 col-md-8 col-lg-8 col-xs-12" style="margin-left:20px;border-style:solid;border-width:1px;border-color:grey;">
						                				<div class="row" style="margin:10px;" id="training">
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="inperson" class="styled" type="checkbox" value="inperson"/>
							                                	<label for="inperson">In Person</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="liveonline" class="styled" type="checkbox" value="liveonline"/>
							                                	<label for="liveonline">Live Online</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="webinars" class="styled" type="checkbox" value="Webinars"/>
							                                	<label for="webinars">Webinars</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="documentation" class="styled" type="checkbox" value="Documentation"/>
							                                	<label for="documentation">Documentation</label>	
							                                </div>
							                            </div>
						                			</div>
					        					</div>
					        					<div class="form-group row">
					        						<label class="col col-sm-6 col-md-3 col-lg-3 col-xs-12 control-label">Support</label>
						                			<div class="col col-sm-5 col-md-8 col-lg-8 col-xs-12" style="margin-left:20px;border-style:solid;border-width:1px;border-color:grey;">
						                				<div class="row" style="margin:10px;" id="support">
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="liverep" class="styled" type="checkbox" value="liverep"/>
							                                	<label for="liverep">24/7 (Live Rep)</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="businesshour" class="styled" type="checkbox" value="businesshour"/>
							                                	<label for="businesshour">Business Hour</label>	
							                                </div>
							                                <div class="checkbox checkbox-success col-lg-12">
							                                	<input id="online" class="styled" type="checkbox" value="onLine"/>
							                                	<label for="online">OnLine</label>	
							                                </div>
							                            </div>
						                			</div>
					        					</div>
				        					</div>
				        				</div>
				        			</div>
			                		
			                	</div>
			                </form>
			            </div>
			         </div>
	        	</div>
	        	<div class="col-lg-6">
	        		<div class="card">
	        			<div class="card-header">
	        				<span class="title-3 m-l-30"><i class="fa fa-gift"></i> Features</span>
	        				<a href="#feature" data-toggle="modal" class="btn btn-primary" style="float:right">Feature Select</a>
	        			</div>
	        			<div class="card-body form">
	        				<form class="form-horizontal">
	        					<div class="form-body  featureEdit">
	        					</div>
	        				</form>
	        			</div>
	        		</div>
	        	</div>
	        </div>
    	</div>
 	</div>
 </div>

 <div class="modal fade bs-modal-lg" id="basic" tabindex="-1" role="dialog" aria-hidden="true">
 	<div class="modal-dialog modal-lg">
 		<div class="modal-content">
	 		<div class="modal-header">
	 			<h4 class="modal-title">Please Select The Category</h4>
	 			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
				
	 		</div>
	 		<div class="modal-body">
	 			<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
					<thead>
	                    <tr>
	                        <th>
	                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
	                                <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
	                                <span></span>
	                            </label>
	                        </th>
	                        <th> Name </th>
	                    </tr>
					</thead>
					<tbody>

						<?php foreach($category as $categories){?>
							<tr class="odd gradeX">
								<td>
	                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
	                                    <input type="checkbox" class="checkboxes category_select" value="<?php echo $categories['id'];?>" />
	                                    <span></span>
	                                </label>
	                            </td>
	                            <td><?php echo $categories['name'];?></td>
							</tr>
						<?php }?>
					</tbody>
				</table>
	 		</div>
	 		<div class="modal-footer">
	            <button type="button" class="btn dark btn-outline" data-dismiss="modal">Close</button>
	        </div>
	    </div>
 	</div>
 </div>
 
 <div class="modal fade bs-modal-lg" id="feature" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Please Select Features</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered table-hover table-checkable order-column feature_select_each" id="sample_2">
                    <thead>
                        <tr>
                            <th>
                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                    <input type="checkbox" class="group-checkable feature_all" data-set="#sample_1 .checkboxes" />
                                    <span></span>
                                </label>
                            </th>
                            <th> Name </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($feature as $features){?>
                            <tr class="odd gradeX">
                                <td>
                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                        <input type="checkbox" class="checkboxes feature_select" value="<?php echo $features['id'];?>"  attr_name="<?php echo $features['name'];?>" attr_type="<?php echo $features['type'];?>"/>
                                        <span></span>
                                    </label>
                                </td>
                                <td><?php echo $features['name'];?></td>
                            </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn dark btn-outline" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
 </div>