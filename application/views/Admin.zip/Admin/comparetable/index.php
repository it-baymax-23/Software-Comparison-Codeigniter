 <!-- BEGIN CONTENT BODY -->
    <div class="main-content p-b-50">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row user-data">
            		<h3 class="title-3 m-b-30"><i class="fa fa-archive"></i>All Compare Tables</h3>
                    <div class="filters m-b-45 col-lg-12">
                        <a href="<?php echo base_url()?>admin/comparetable/newtable" class="btn btn-primary active">
                            Add New<i class="fa fa-plus" style="margin-left:10px;"></i>
                        </a>
                    </div>
                    <div class="col-lg-12"  style="padding:30px 20px">
                        <table class="table table-striped table-bordered table-hover table-checkable order-column table-responsible" id="sample_1" style="text-align: center;vertical-align: center;">
                            <thead>
                                <tr>
                                    <th>
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                            <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                            <span></span>
                                        </label>
                                    </th>
                                    <th> Name </th>
                                    <th> Slug </th>
                                    <th>Activated</th>
                                    <th>Created_date</th>
                                    <th style="width:100px;"> Actions </th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php foreach($compare as $compares){?>
                                    <tr class="odd gradeX">
                                        <td>
                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="<?php echo $compares['id'];?>" />
                                                <span></span>
                                            </label>
                                        </td>
                                        <td><?php echo $compares['name'];?></td>
                                        <td><?php echo base_url() . 'basecompare/' . $compares['slug'];?></td>
                                        <td>
                                           <label class="switch">
                                              <input class="activate" type="checkbox" attr_id="<?php echo $compares['id'];?>" <?php if($compares['activated']){echo 'checked';}?>>
                                              <span class="slider_checkbox round"></span>
                                            </label>
                                        </td>
                                        <td><?php echo $compares['created_date'];?></td>
                                        <td>
                                            <a class="btn btn-primary edit" href="<?php echo base_url();?>admin/comparetable/newtable/<?php echo $compares['id'];?>" style="margin-top: 5px;" alt="Edit">
                                                 <i class="fa fa-edit"></i>
                                            </a>
                                            <span class="btn btn-danger deletecompare" style="margin-top:5px;" attr_id="<?php echo $compares['id'];?>">
                                                <i class="fa fa-trash"></i>
                                            </span>
                                        </td>
                                    </tr>
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
