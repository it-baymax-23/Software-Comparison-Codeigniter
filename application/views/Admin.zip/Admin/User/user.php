
    <!-- BEGIN CONTENT BODY -->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <div class="user-data col-lg-12 m-b-30">
                    	<div class="portlet box green">
                    		<h3 class="title-3 m-b-30"><i class="fa fa-archive"></i>All Users</h3>
                            <div class="filters m-b-45">
                                <a href="<?php echo base_url();?>admin/user/newuser/buyer" id="add_new_user" class="btn btn-primary">
                                    Add New<i class="fa fa-plus" style="margin-left:10px;"></i>
                                </a>
                                <button id="delete_user" class="btn btn-danger pull-right">
                                    Delete Selected<i class="fa fa-trash" style="margin-left:10px;"></i>
                                </button>
                            </div>
                            <div class="row">
                                <div class="col-lg-12"  style="padding:30px 20px">
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column table-scrollable" id="sample_1">
                                    <thead>
                                        <tr>
                                            <th>
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                    <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th>Profile</th>
                                            <th> User Name </th>
                                            <th> Email Address </th>
                                            <th>industry</th>
                                            <th> Activated </th>
                                            <th>Popular</th>
                                            <th> Actions </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($user as $users){?>
                                            <tr class="odd gradeX">
                                                <td>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" class="checkboxes" value="<?php echo $users['id'];?>" />
                                                        <span></span>
                                                    </label>
                                                </td>
                                                <td style="padding:10px;"><img src="<?php echo base_url() . $users['profile'];?>" style="width:100px;height:100px;"></td>
                                                <td style="vertical-align: middle;text-align: center;"><?php echo $users['username'];?></td>
                                                <td  style="vertical-align: middle;text-align: center;"><?php echo $users['email'];?></td>
                                                <td  style="vertical-align: middle;text-align: center;"><?php echo $users['industry'];?></td>
                                                <td  style="vertical-align: middle;text-align: center;"><?php echo $users['activated']?'<i class="fas fa-check-circle" style="color:green;font-size:30px;"></i>':'<i class="fas fa-check-circle" style="font-size:30px;"></i>';?></td>
                                                <td  style="vertical-align: middle;text-align: center;">
                                                    <?php if($users['usertype'] == 'vendor'){?>
                                                    <label class="switch">
                                                      <input class="popular" type="checkbox" attr_id="<?php echo $users['id'];?>" <?php if($users['popular'] && $users['usertype'] == 'vendor'){echo 'checked';}?>>
                                                      <span class="slider_checkbox round"></span>
                                                    </label>
                                                    <?php }?>
                                                </td>
                                                <td class="btn-group" >
                                                    <button type="button" class="btn green btn-sm btn-outline dropdown-toggle" data-toggle="dropdown"> Actions
                                                    </button>
                                                    <ul class="dropdown-menu pull-right account-dropdown__body" role="menu">
                                                        <div class="account-dropdown__body">
                                                            <div class="account-dropdown__item">
                                                                <a href="<?php echo base_url();?>admin/user/edituser/buyer/<?php echo $users['id'];?>">
                                                                    <i class="fa fa-edit"></i> Edit</a>
                                                            </div>
                                                            <div class="account-dropdown__item">
                                                                <a href="javascript:;" class="<?php echo $users['activated']?'deactivate':'activate';?>" attr_id = '<?php echo $users['id'];?>' style="font-size:10px;">
                                                                    <i class="fas fa-shield-alt"></i> <?php echo $users['activated']?'DeActivate':'Activate';?></a>
                                                            </div>
                                                            <div class="account-dropdown__item">
                                                                <a href="javascript:;" class="delete" attr-id="<?php echo $users['id'];?>">
                                                                    <i class="fa fa-trash"></i> Delete</a>
                                                            </div>
                                                            <div class="account-dropdown__item">
                                                                <a class="moreinfo" attr-id="<?php echo $users['id'];?>" style="cursor:pointer;">
                                                                    <i class="fa fa-info"></i> More View</a>
                                                            </div>
                                                            
                                                        </div>
                                                    </ul>
                                                </td>
                                            </tr>
                                        <?php }?>
                                    </tbody>
                                    </table> 
                                </div>   
                            </div>
                    	</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bs-modal-lg" id="basic" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Your User Info</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                
            </div>
            <div class="modal-body">
              <div class="row m-t-30">
                    <label class="col-lg-3">Profile</label>
                    <div class="col-lg-9 profile"></div>
              </div>
              <div class="row m-t-30">
                  <label class="col-lg-3">First Name</label>
                  <span class="col-lg-3 firstname"></span>
                  <div class="col-lg-1"></div>
                  <label class="col-lg-3">Last Name</label>
                  <span class="col-lg-2 lastname"></span>
              </div>
              <div class="row m-t-30">
                  <label class="col-lg-3">Email Address</label>
                  <span class="col-lg-3 email"></span>
                  <div class="col-lg-1"></div>
                  <label class="col-lg-3">Phone Number</label>
                  <span class="col-lg-2 phone"></span>
              </div>
              <div class="row m-t-30">
                  <label class="col-lg-3">Website</label>
                  <span class="col-lg-3 website"></span>
                  <div class="col-lg-1"></div>
                  <label class="col-lg-3">Company</label>
                  <span class="col-lg-2 company"></span>
              </div>
              <div class="row m-t-30">
                  <label class="col-lg-3">Company Size</label>
                  <span class="col-lg-3 company_size"></span>
                  <div class="col-lg-1"></div>
                  <label class="col-lg-3">User Type</label>
                  <span class="col-lg-2 usertype"></span>
              </div>
              <div class="row m-t-30">
                  <label class="col-lg-3">User Name</label>
                  <span class="col-lg-3 username"></span>
              </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger btn-outline" data-dismiss="modal">Close</button>                
            </div>
        </div>
    </div>
 </div>