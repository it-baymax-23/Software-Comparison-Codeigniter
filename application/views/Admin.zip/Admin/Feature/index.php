<div class="main-content p-b-50">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row user-data">
                    <div class="col-md-12">
                    	<div class="portlet box green">
                    		<div class="portlet-title">
                    			<div class="caption">
                    				<h3 class="title-3"><i class="fa fa-archive"></i>All Features</h3>
                    			</div>
                                <div class="filters m-b-45"  style="padding:30px 20px">
                                    <a href="<?php echo base_url()?>admin/feature/newfeature" id="add_new_feature" class="btn btn-primary">
                                        Add New<i class="fa fa-plus" style="margin-left:10px;"></i>
                                    </a>
                                    <button id="delete_feature" class="btn btn-danger pull-right">
                                        Delete Selected<i class="fa fa-trash" style="margin-left:10px;"></i>
                                    </button>
                                </div>
                    		</div>
            				<div class="col-md-12" style="padding:30px 20px">
    	        				<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
    	        					<thead>
    	                                <tr>
    	                                    <th>
    	                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
    	                                            <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
    	                                            <span></span>
    	                                        </label>
    	                                    </th>
    	                                    <th> Name </th>
    	                                    <th> Type </th>
    	                                    <th style="width:100px;"> Actions </th>
    	                                </tr>
    	        					</thead>
    	        					<tbody>
    	        						<?php foreach($feature as $features){?>
    	        							<tr class="odd gradeX">
    	        								<td>
    	                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
    	                                                <input type="checkbox" class="checkboxes" value="<?php echo $features['id'];?>" />
    	                                                <span></span>
    	                                            </label>
    	                                        </td>
                                                <td><?php echo $features['name'];?></td>
                                                <td><?php echo $features['type'];?></td>
                                                <td>
                                                	<a class="btn btn-primary edit" href="<?php echo base_url();?>admin/feature/newfeature/<?php echo $features['id'];?>">
                                                		 <i class="fa fa-edit"></i>
                                                	</a>
                                                	<span class="btn btn-danger delete">
                                                		<i class="fa fa-trash"></i>
                                                	</span>
                                                </td>
    	        							</tr>
    	        						<?php }?>
    	        					</tbody>
    	        				</table>
    	        			</div>
                    	</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 </div>