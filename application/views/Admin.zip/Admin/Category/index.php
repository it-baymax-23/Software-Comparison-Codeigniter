
    <!-- BEGIN CONTENT BODY -->
    <div class="main-content p-b-50">
        <div class="section__content section__content--p30 p-b-100">
            <div class="container-fluid">
                <div class="row user-data">
            		<h3 class="title-3 m-b-30"><i class="fa fa-archive"></i>All Categories</h3>
                    <div class="filters m-b-45 col col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="row">
                            <a href="<?php echo base_url()?>admin/category/newcategory" class="col-xs-12 col-sm-4 col-md-3 col-lg-3 btn btn-primary active m-b-10">
                                Add New<i class="fa fa-plus" style="margin-left:10px;"></i>    
                            </a>
                            <div class="col-xs-12 col-sm-4 col-md-6 col-lg-6"></div>
                            <span id="delete_category" class="col-xs-12 col-sm-4 col-md-3 col-lg-3 btn btn-danger" style="height:38px;">
                                Delete Selected<i class="fa fa-trash" style="margin-left:10px;"></i>
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-12"  style="padding:30px 20px">
                        <table class="table table-striped table-bordered table-hover table-checkable order-column table-responsible" id="sample_1">
                            <thead>
                                <tr>
                                    <th>
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                            <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                            <span></span>
                                        </label>
                                    </th>
                                    <th> Name </th>
                                    <th> Description </th>
                                    <th>Popular</th>
                                    <th style="width:100px;"> Actions </th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php foreach($category as $categories){?>
                                    <tr class="odd gradeX">
                                        <td>
                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="<?php echo $categories['id'];?>" />
                                                <span></span>
                                            </label>
                                        </td>
                                        <td><?php echo $categories['name'];?></td>
                                        <td><?php echo $categories['description'];?></td>
                                        <td>
                                            <label class="switch">
                                              <input class="popular" type="checkbox" attr_id="<?php echo $categories['id'];?>" <?php if($categories['popular']){echo 'checked';}?>>
                                              <span class="slider_checkbox round"></span>
                                            </label>
                                        </td>
                                        <td>
                                            <a class="btn btn-primary edit" href="<?php echo base_url();?>admin/category/newcategory/<?php echo $categories['id'];?>" style="margin-top: 5px;" alt="Edit">
                                                 <i class="fa fa-edit"></i>
                                            </a>
                                            <span class="btn btn-danger deletecategory" style="margin-top:5px;">
                                                <i class="fa fa-trash"></i>
                                            </span>
                                        </td>
                                    </tr>
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
