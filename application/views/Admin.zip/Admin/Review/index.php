
    <!-- BEGIN CONTENT BODY -->
    <div class="main-content p-b-50">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row user-data">
            		<h3 class="title-3 m-b-30"><i class="fas fa-star"></i>All Reviews</h3>             		
    				<div class="col-md-12 col-lg-12" style="padding:30px 20px">
        				<table class="table table-striped table-bordered table-hover order-column" id="sample_1">
        					<thead>
                                <tr>
                                    <th style="width:100px;"> product </th>
                                    <th> product name </th>
                                    <th>title</th>
                                    <th>Over all</th>
                                    <th>Activate</th>
                                    <th>Action</th>
                                </tr>
        					</thead>
        					<tbody>
        						<?php foreach($review as $reviews){?>
        							<tr class="odd gradeX">
                                        <td><img src="<?php echo base_url() . $reviews['logo'];?>" style="width:100px;height:100px;"/></td>
                                        <td style="vertical-align: middle;text-align: center;"><?php echo $reviews['name'];?></td>
                                        <td style="vertical-align: middle;text-align: center;">
                                        	<?php echo $reviews['title'];?>
                                        </td>
                                        <td style="vertical-align: middle;text-align: center;">
                                            <?php for($index = 0;$index<$reviews['over_all'];$index++){?>
                                            <i class="fas fa-star" style="color:yellow"></i>
                                            <?php }?>
                                            <?php for($index = $reviews['over_all'];$index<5;$index++){?>
                                            <i class="far fa-star"></i>
                                            <?php }?>
                                        </td>
                                        <td style="vertical-align: middle;text-align: center;">
                                            <label class="switch">
                                              <input class="activate" type="checkbox" attr_id="<?php echo $reviews['id'];?>" <?php if($reviews['activate']){echo 'checked';}?>>
                                              <span class="slider_checkbox round"></span>
                                            </label>
                                        </td>
                                        <td style="vertical-align: middle;text-align: center;">
                                        	<a class="btn btn-primary editreview" href="<?php echo base_url();?>admin/review/editreview/<?php echo $reviews['id'];?>" style="margin-top: 5px;">
                                        		<i class="fa fa-edit"></i>
                                        	</a>
                                        	<span class="btn btn-danger deletereview" attr_id="<?php echo $reviews['id']; ?>" style="margin-top:5px;">
                                        		<i class="fa fa-trash"></i>
                                        	</span>
                                        </td>
        							</tr>
        						<?php }?>
        					</tbody>
        				</table>
        			</div>
                </div>
            </div>
        </div>
    </div>
